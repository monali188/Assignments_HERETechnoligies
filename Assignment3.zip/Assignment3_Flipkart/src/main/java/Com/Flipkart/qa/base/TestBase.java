package Com.Flipkart.qa.base;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class TestBase {

public static WebDriver driver;
	
	//a. Go to the below URL: https://www.google.com/maps/
	public static void initialization() 
	{
		System.setProperty("webdriver.chrome.driver","C:\\Installer\\chromedriver_win32\\chromedriver.exe");
		  driver = new ChromeDriver(); 
		 
		 driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		// driver.manage().window().maximize();
		 driver.get("https://www.flipkart.com");
		 driver.findElement(By.xpath("//button[@class=\"_2KpZ6l _2doB4z\"]")).click();
		 
		 
	}
	
}
