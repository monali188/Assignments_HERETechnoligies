package Com.Flipkart.qa.base;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class HomePage extends TestBase{
	Actions act = new Actions(driver);
	
	public HomePage()
	{
		PageFactory.initElements(driver,this);
	}
	
@FindBy(xpath="//img[@alt='Mobiles']")
WebElement MClick;

@FindBy(xpath="(//span[@class=\"_2I9KP_\"])[1]")
WebElement Ele;

@FindBy(xpath="//a[@title='Mi']")
WebElement MIItem;

public void MobileClick() throws InterruptedException
{
	MClick.click();
    Actions act = new Actions(driver);
    act.moveToElement(Ele).build().perform();
    Thread.sleep(2000);
    act.moveToElement(MIItem).click().build().perform();
    Thread.sleep(2000);
}

//5. Change the PRICE Slider (Use Actions class)
@FindBy(xpath="//div[@class=\"_31Kbhn WC_zGJ\"]")
 WebElement Source;
@FindBy(xpath="//div[@class=\"_2IN3-t _1mRwrD\"]")
WebElement Target;

public void ChangePrice()
{
	Actions act = new Actions(driver);
	act.clickAndHold(Source).moveToElement(Target).release().build().perform();
}

//6. Choose the third option from the Max Dropdown under PRICE Slider (Handle Dropdowns)
@FindBy(xpath="//div[@class='_3uDYxP']//select[@class='_2YxCDZ']")
WebElement maxprice;

public void Select3Max() 
{
	Select s=new Select(maxprice);
	s.selectByValue("7000");
}
//7.Search for �redmi go (black, 8 gb)� in the search bar

@FindBy(xpath="//input[@placeholder='Search for products, brands and more']")
WebElement searchtext;

@FindBy(xpath="//button[@type=\"submit\"]")
WebElement search;

public void SerachRedmi() throws InterruptedException
{
	searchtext.sendKeys("redmi go (black, 8 gb)");
	Thread.sleep(2000);
	search.click();
	Thread.sleep(2000);
}
//8. Click on the first product displayed on the screen
//9. Verify that the product amount should be greater than or equal to 0 (Use switch to new window)
@FindBy(xpath="//div[normalize-space()='Redmi Go (Black, 8 GB)']")
WebElement FirstProduct;

@FindBy(xpath="//div[@data-id='MOBFDZQHCJFYXZHX']//div[@class='_25b18c']//div[1]")
WebElement ProductAmt;
public void verifyProductAmt()
{
	FirstProduct.click();
	String s=ProductAmt.getText();
	try
	{
		int amount=Integer.parseInt(s);  
		if(amount>=0)
		{
			ProductAmt.click();
		}
	}
	catch(NumberFormatException e)
	{
		
	}
}



		
		
}
	 
