package com.Flipkart.qa.Testcase;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import Com.Flipkart.qa.base.HomePage;
import Com.Flipkart.qa.base.TestBase;


public class HomePageTest extends TestBase {
	HomePage hp;
	public HomePageTest()
	{
		super();
	}
	
	@BeforeMethod
	public void Setup() throws Exception
	{
		initialization();
		hp=new HomePage();
	}
	
	@Test(priority=1,groups="Sanity")
	public void MobileClickTest() throws InterruptedException
	{
		hp.MobileClick();
		Thread.sleep(2000);
	}
	@Test(priority=2,groups="Sanity")
	public void ChangePriceTest() throws InterruptedException
	{
		hp.MobileClick();
		Thread.sleep(2000);
		hp.ChangePrice();
		Thread.sleep(2000);
	}
	@Test(priority=1,groups="Sanity")
	public void Select3MaxTest() throws InterruptedException
	{
		hp.MobileClick();
		Thread.sleep(2000);
		hp.Select3Max();
		Thread.sleep(2000);
		
	}
	@Test(priority=1,groups="Rgression")
	public void SearchRedmiTest() throws InterruptedException
	{
		hp.SerachRedmi();
	}
	@Test(priority=1,groups="Rgression")
	public void VerifyProductAmtTest() throws InterruptedException
	{
		hp.SerachRedmi();
		hp.verifyProductAmt();
	}
	
	
	
@AfterMethod
	public void tearDown()
	{
		driver.close();
	}


}
