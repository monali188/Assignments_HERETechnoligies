package Assignment4.DataTable;

public class DataTable {

}
