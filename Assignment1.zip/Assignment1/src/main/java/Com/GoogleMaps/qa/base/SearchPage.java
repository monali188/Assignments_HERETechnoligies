package Com.GoogleMaps.qa.base;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SearchPage extends Base{
	 
@FindBy(id="searchboxinput")
WebElement stext;
 

@FindBy(xpath="(//div[@class=\"DgCNMb\"])[1]")
WebElement text;

@FindBy(xpath="//span[text()=\"Wankhede Stadium\"]")
WebElement text1;

@FindBy(xpath="(//span[text()=\"4.5\"])[1]")
WebElement rating;

@FindBy(xpath="(//button[@class=\"DkEaL\"])[1]")
WebElement reviews;

@FindBy(xpath="//div[text()=\"mumbaicricket.com\"]")
WebElement link;

@FindBy(xpath="//div[text()=\"WRQG+G8R, Vinoo Mankad Rd, Churchgate, Mumbai, Maharashtra 400020\"]")
WebElement address;

@FindBy(xpath="//div[text()=\"022 2279 5500\"]")
WebElement phoneNo;

public SearchPage()
{
PageFactory.initElements(driver, this);	
}

//Search for �Wankhede Stadium�
public void searchText() 
{
stext.sendKeys("Wankhede Stedium");	
}

//click on Maps
public void clickText()
{
	text.click();
}

//d. Verify the Text Present �Stadium� in the left frame

public void verifyText()
{
	String s1=text1.getText();
	String s="Stadium";
	 if(s1.contains(s))
	 {
		 System.out.println("Text Present:   "+s);
	 }
	 else
	 {
		 System.out.println("Text not Present");
	 }
}

//e. Verify the Title �Wankhede Stadium - Google Maps�

public String verifyTitle() {
	return driver.getTitle();
}

//Print the ratings point 
public String PrintRatings()
{
	return rating.getText();
}

//print number of reviews in the console
public String PrintReviews()
{
	return reviews.getText();	
}

//Verify that link is Present �mumbaicricket.com� on the left frame.
public boolean VerifyLink()
{
	return link.isDisplayed();
}

//Print the address appearing above the �mumbaicricket.com�
public String PrintAddress()
{
	return address.getText();
}

//Verify that the phone number �022 2279 5500� is present
public boolean verifyPhoneNo()
{
	return phoneNo.isDisplayed();
	
}


}


