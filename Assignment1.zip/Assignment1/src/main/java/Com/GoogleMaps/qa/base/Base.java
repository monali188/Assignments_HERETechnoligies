package Com.GoogleMaps.qa.base;

import java.io.File;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Base {
	
public static WebDriver driver;
	
	//a. Go to the below URL: https://www.google.com/maps/
	public static void initialization() {
		System.setProperty("webdriver.chrome.driver","C:\\Installer\\chromedriver_win32\\chromedriver.exe");
		  driver = new ChromeDriver(); 
		 
		 driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		 driver.manage().window().maximize();
		 driver.get("https://www.google.com/maps");
		 
	}
	
	//c. Save the screen shot image at this test execution instant
		   
		public void TakeScreenShot() throws Exception{
		    TakesScreenshot scrShot =((TakesScreenshot)driver);
		    File SourceFile=scrShot.getScreenshotAs(OutputType.FILE);
		    File DestFile=new File("C:\\Users\\monal\\eclipse-workspace\\Assignment1\\Screenshot/"
		    		+ "GoogleMap.png");
		    FileUtils.copyFile(SourceFile, DestFile);
		}
    
}



