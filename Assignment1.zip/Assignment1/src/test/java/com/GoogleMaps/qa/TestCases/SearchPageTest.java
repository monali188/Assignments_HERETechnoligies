package com.GoogleMaps.qa.TestCases;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import Com.GoogleMaps.qa.base.Base;
import Com.GoogleMaps.qa.base.SearchPage;


public class SearchPageTest extends Base{
	SearchPage s;
	
	public SearchPageTest() {
		super();  //how call super class const - using super keyword
	}
	@BeforeMethod
	public void Setup() throws Exception
	{
		initialization();
		s=new SearchPage();
		s.searchText();
		Thread.sleep(3000);
		s.clickText();
		Thread.sleep(3000);
		TakeScreenShot();	
		
	}

	@Test(priority=1)
	public void VerifyTextTest()
	{
		s.verifyText();
	}
	@Test(priority=2)
	public void VerifyTitleTest()throws InterruptedException
	{		
		String Title = s.verifyTitle();
		Assert.assertEquals(Title, "Wankhede Stadium - Google Maps");
		System.out.println("title Verified  "+Title);
	}
	@Test(priority=3)
	public void PrintRatingsReviews()
	{		
		String Ratings=s.PrintRatings();
		System.out.println("Ratings are: "+Ratings);
		
		String Reviews=s.PrintReviews();
		System.out.println("Reviews are: "+Reviews);		
	}
	@Test(priority=4)
	public void VerifyLinkTest()
	{
		boolean Link=s.VerifyLink();
		Assert.assertTrue(true);
		System.out.println("Link Verified "+Link);
	}

	@Test(priority=5)
	public void PrintAddressTest()
	{
		String Address=s.PrintAddress();
		System.out.println("Address: "+Address);
	}
	
	@Test(priority=6)
	public void VerifyPhoneNoTest()
	{
		boolean Pno=s.verifyPhoneNo();
		Assert.assertTrue(true);
		System.out.println("Phone No Verified "+Pno);
	}
	@Test(priority=7)
	public void TakeScreenshot() throws Exception
	{
		TakeScreenShot();	
	}
	
	@AfterMethod
	public void tearDown()
	{
		driver.close();
	}

}
