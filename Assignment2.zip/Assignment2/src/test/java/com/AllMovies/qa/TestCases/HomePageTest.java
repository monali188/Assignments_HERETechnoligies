package com.AllMovies.qa.TestCases;

import org.openqa.selenium.support.FindBy;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.AllMovie.qa.base.HomePage;
import com.AllMovie.qa.base.TestBase;

public class HomePageTest extends TestBase {

	HomePage homepage;
	
	public HomePageTest() {
		super();  //how call super class const - using super keyword
	}
	@BeforeMethod
	public void Setup() throws Exception
	{
		initialization();
		homepage=new HomePage();
		
	}
	@Test(priority=1)
	public void PrintSearchItemTest() throws Exception 
	{
		homepage.printSearchItem();
	}
	
	@Test(priority=2)
	public void ClickMovieLinkTest()
	{
		homepage.ClickMovieLink();
	}
	
	@Test(priority=3)
	public void verifyGenreRatingTest()
	{
		homepage.ClickMovieLink();
	    homepage.verifyGenreRating();
	}
	
	@Test(priority=4)
	public void verifyDirectorNameTest()
	{
		homepage.ClickMovieLink();
		String DirectorName=homepage.verifyDirectorName();
		Assert.assertEquals(DirectorName, "Francis Ford Coppola");
		System.out.println("Director Name Verified");
	}
	
	@Test(priority=5)
	public void verifyCharecterNameTest()
	{
		homepage.ClickMovieLink();
		homepage.verifyDirectorName();
		homepage.verifyCharecterName();
		
	}
	@AfterMethod
	public void tearDown()
	{
		driver.close();
	}
	

}
