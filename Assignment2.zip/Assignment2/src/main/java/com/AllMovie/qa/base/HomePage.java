package com.AllMovie.qa.base;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class HomePage extends TestBase{
	
	public HomePage()
	{
		PageFactory.initElements(driver, this);
	}
	
	//a. Print number of search results items found in eclipse console
	
	@FindBy(xpath="//div[@class=\"content-container\"]//div")
	List<WebElement> SearchResult;
		
	public void printSearchItem()throws Exception
	{				
		for(WebElement link:SearchResult)
		{
		System.out.println(link.getText());//prints all Search Results
		}
	}

	//b. Click on the movie link page with release year �1972�

@FindBy(xpath="(//a[contains(text(),\"The Godfather\")])[1]")
WebElement link1972;

public void ClickMovieLink()
{
	link1972.click();
}

//c. Verify that the movie�s genre is �Crime� and MPAA rating is �A�.

@FindBy(xpath="//span[@class=\"header-movie-genres\"]")
WebElement genre;

@FindBy(xpath="//span[text()=\"R\"]")
WebElement rating;

public void verifyGenreRating()
{
	String ActualGenre= genre.getText();
	String ExpGenre="Crime";
	String Actrating=rating.getText();
	String Exprating="A";
	if(ActualGenre.contains(ExpGenre)&& Actrating.equals(Exprating))
	{
		System.out.println("Test case Pass "+ActualGenre+" MPAA rating= "+Actrating);
	}
	else
	{
		System.out.println("Test case Failed "+ActualGenre+" MPAA rating= "+Actrating);
	}
}

//d. Verify on Cast & Crew page that the movie�s director�s name is �Francis Ford Coppola�

@FindBy(xpath="//a[@title=\"Cast & Crew\"]")
WebElement castlink;

@FindBy(xpath="(//a[text()=\"Francis Ford Coppola\"])[2]")
WebElement Directorname;

public String verifyDirectorName()
{
	castlink.click();
	return Directorname.getText();
}

//e. Verify on Cast & Crew page that the Al Pacino�s character�s name is Michael Corleone

@FindBy(xpath="(//a[text()=\"Al Pacino\"])[1]")
WebElement heroname;

@FindBy(xpath="(//div[@class=\"cast_role\"])[2]")
WebElement charectername;

public void verifyCharecterName()
{
	String HeroName=heroname.getText();
	String CharName=charectername.getText();
	if(HeroName==CharName)
	{
		System.out.println("Character Name Verified");
	}
	else
	{
		System.out.println("Charecter name not verified");
	}
}
}
