package com.AllMovie.qa.base;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class TestBase {

public static  WebDriver driver;
	
	//open http://www.allmovie.com
	public static void initialization() throws InterruptedException {
		System.setProperty("webdriver.gecko.driver","C:\\Installer\\GeckoDriver_win32\\geckodriver.exe");
		driver = new FirefoxDriver(); 
		 
		 driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		 //driver.manage().window().maximize();
		 driver.get("http://www.allmovie.com");
		 
		 driver.findElement(By.xpath("//input[@type=\"search\"]")).sendKeys("The Godfather");
			Thread.sleep(2000);
		driver.findElement(By.linkText("See All Results for \"the godfather\"")).click();
		Thread.sleep(2000);
		 
	}
}
